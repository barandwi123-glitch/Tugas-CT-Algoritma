Tugas Algoritma Keramik 2xN
---------------------------------

File ini berisi:
1. index.html → Program visualisasi penyusunan keramik 2xN
2. README.txt → Penjelasan singkat algoritma

Algoritma:
Program menggunakan rekursi untuk menghasilkan seluruh kombinasi:
- 'V' = keramik vertikal (mengurangi panjang N sebesar 1)
- 'H' = keramik horizontal (mengurangi panjang N sebesar 2)

Setelah semua kombinasi ditemukan, sistem membuat visualisasi berupa kotak-kotak keramik.

File ini siap di-upload ke LMS UIN.
